var DATA = [
      { id:0, label:"com.google.chromeos.vpn", link:"reference/com/google/chromeos/vpn/package-summary.html", type:"package", deprecated:"false" },
      { id:1, label:"com.google.chromeos.vpn.VpnServiceBuilderCompat", link:"reference/com/google/chromeos/vpn/VpnServiceBuilderCompat.html", type:"class", deprecated:"false" }

    ];
